#ifndef HsRxCh
#define HsRxCh
class HRC_
{
public:
	HRC_();
	int CH();
	int kn[5], KN;
private:
	int rx[5], i = 0 , i2, rx_len;
};
#endif