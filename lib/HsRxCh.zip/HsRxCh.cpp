#include "HsRxCh.h"
#include "arduino.h"

HRC_::HRC_(){
	
};

int HRC_::CH(){
	
    while(1){
		
        while (Serial1.available()) {
			delay(10);
            rx[i] = Serial1.read();
            i++;
			
        }
		
        if(i == 5 && rx[4] != 10){
			
        	while(Serial1.read() >= 0);{
				Serial1.read();
			}
        	Serial.println("Outline!");
    		rx[4] = 10;
			
        }
		
        if(rx[i-1] == 10){
			
            rx_len = i - 1;
            i2 = rx_len;
    		i = 0;
            goto B;
			
        }
    }
B:
    if (rx_len > 0){       
        int y = 0;
        int num = 1;
        while(rx_len){
			
            switch(rx[y]){
				case 48 : kn[y] = 0;
					break;
				case 49 : kn[y] = 1;
					break;
				case 50 : kn[y] = 2;
					break;
				case 51 : kn[y] = 3;
					break;
				case 52 : kn[y] = 4;
					break;
				case 53 : kn[y] = 5;
					break;
				case 54 : kn[y] = 6;
					break;
				case 55 : kn[y] = 7;
					break;
				case 56 : kn[y] = 8;
					break;
				case 57 : kn[y] = 9;
					break;
			}
        
			rx_len--;
			y++;
			num++;
			
		}//while(rx_len)
			
        switch(i2){
            case 1 : KN = kn[0];
                break;
            case 2 : KN = kn[0]*10 + kn[1];
                break;
            case 3 : KN = kn[0]*100 + kn[1]*10 + kn[2];
                break;
			case 4 : KN = kn[0]*1000 + kn[1]*100 + kn[2]*10 + kn[3];
                break;
        }
		return KN;
	}//if(rx_len > 0)
};
