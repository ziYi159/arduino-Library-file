#ifndef TB6612FNG
#define TB6612FNG
class TBF_
{
	
public:
	TBF_();
	void SET_PINS(int ain1, int ain2, int bin1, int bin2, int pwma, int pwmb);
	void SET_AIN(int AV1, int AV2, int PVA);
	void SET_BIN(int BV1, int BV2, int PVB);
	void ALL_IN(int PV);
	void ALL_CK(int PV);
	void AIN_BCK(int PV);
	void BIN_ACK(int PV);
	void STOP();
private:
	int AIN1, AIN2, BIN1, BIN2, PWMA, PWMB;
};
#endif