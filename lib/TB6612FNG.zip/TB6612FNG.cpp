#include "TB6612FNG.h"
#include "arduino.h"

TBF_::TBF_(){

};

void TBF_::SET_PINS(int ain1, int ain2, int bin1, int bin2, int pwma, int pwmb){
	
	AIN1 = ain1;
    AIN2 = ain2;
    BIN1 = bin1;
    BIN2 = bin2;
    PWMA = pwma;
	PWMB = pwmb;
	pinMode(AIN1,OUTPUT);
	pinMode(AIN2,OUTPUT);
	pinMode(BIN1,OUTPUT);
	pinMode(BIN2,OUTPUT);
	pinMode(PWMA,OUTPUT);
	pinMode(PWMB,OUTPUT);
	
};

void TBF_::SET_AIN(int AV1, int AV2, int PVA){
	
	analogWrite(PWMA, PVA);
	digitalWrite(AIN1, AV1);
	digitalWrite(AIN2, AV2);
	
};

void TBF_::SET_BIN(int BV1, int BV2, int PVB){
	
	analogWrite(PWMB, PVB);
    digitalWrite(BIN1, BV1);
    digitalWrite(BIN2, BV2);
	
};

void TBF_::ALL_IN(int PV){
	
	analogWrite(PWMA, PV);
	analogWrite(PWMB, PV);
	digitalWrite(AIN1, 1);
	digitalWrite(AIN2, 0);
	digitalWrite(BIN1, 1);
    digitalWrite(BIN2, 0);
	
};

void TBF_::ALL_CK(int PV){
	
	analogWrite(PWMA, PV);
	analogWrite(PWMB, PV);
	digitalWrite(AIN1, 0);
    digitalWrite(AIN2, 1);
	digitalWrite(BIN1, 0);
    digitalWrite(BIN2, 1);
	
};

void TBF_::AIN_BCK(int PV){
	
	analogWrite(PWMA, PV);
	analogWrite(PWMB, PV);
	digitalWrite(AIN1, 1);
    digitalWrite(AIN2, 0);
	digitalWrite(BIN1, 0);
    digitalWrite(BIN2, 1);
	
};

void TBF_::BIN_ACK(int PV){
	
	analogWrite(PWMA, PV);
	analogWrite(PWMB, PV);
	digitalWrite(AIN1, 0);
    digitalWrite(AIN2, 1);
	digitalWrite(BIN1, 1);
    digitalWrite(BIN2, 0);
	
};

void TBF_::STOP(){
    
	digitalWrite(AIN1, 0);
    digitalWrite(AIN2, 0);
	digitalWrite(BIN1, 0);
    digitalWrite(BIN2, 0);
	
};