#include "GY25.h"
#include "arduino.h"


GY25_::GY25_(){
	
};

void GY25_::begin()
{
	Serial1.begin(115200);
	delay(3000);
	Serial1.write(0XA5);
	Serial1.write(0X52);
};

void GY25_::Rx() {
  while (Serial1.available()) {   
    Rxs[i]=(unsigned char)Serial1.read();
    if(i==0&&Rxs[0]!=0xAA) 
  return;          
    i++;       
    if(i==8)                
    {    
       i=0;                 
       sign=1;
    }      
  }
};

void GY25_::Tx(){
	Rx();
	if(sign)
	{  
		sign=0;
		if(Rxs[0]==0xAA && Rxs[7]==0x55)        
		{           
			XYZ[2]=(Rxs[5]<<8|Rxs[6])/70;
			XYZ[1]=(Rxs[3]<<8|Rxs[4])/100;
			XYZ[0]=(Rxs[1]<<8|Rxs[2])/100;
			ZV = XYZ[0];
			YV = XYZ[1];
			XV = XYZ[2];
			delay(10);           
		}
	} 
};
