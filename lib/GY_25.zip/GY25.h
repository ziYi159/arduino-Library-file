#ifndef GY25
#define GY25
class GY25_
{
public:
	GY25_();
	void begin();
	int XV, YV, ZV;
private:
	void Tx();
	void Rx();
	int XYZ[3];
	unsigned char Rxs[8],i=0;
	unsigned char sign=0;
};
#endif